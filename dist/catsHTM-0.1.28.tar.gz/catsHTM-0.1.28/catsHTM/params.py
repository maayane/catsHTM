path_catalogs=''# you cann add the path to the catalog here and use import params.py
IndexFileTemplate='%s_htm.hdf5'
CatFileTemplate='%s_htm_%06d.hdf5'
htmTemplate='htm_%06d'
NcatinFile=100.
ColCelFile = '%s_htmColCell.mat'
