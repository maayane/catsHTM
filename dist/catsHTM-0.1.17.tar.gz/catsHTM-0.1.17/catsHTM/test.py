import catsHTM
path='../../data'
catsHTM.xmatch_2cats('FIRST','FIRST',catalogs_dir=path)
