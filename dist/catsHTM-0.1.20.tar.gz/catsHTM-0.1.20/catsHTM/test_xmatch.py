path='../../data'

import catsHTM

catsHTM.xmatch_2cats('FIRST','AKARI',catalogs_dir=path)
