path_catalogs='/Users/maayanesoumagnac/PostDoc/projects/catsHTM/data/'
IndexFileTemplate='%s_htm.hdf5'
CatFileTemplate='%s_htm_%06d.hdf5'
htmTemplate='htm_%06d'
NcatinFile=100.
ColCelFile = '%s_htmColCell.mat'
