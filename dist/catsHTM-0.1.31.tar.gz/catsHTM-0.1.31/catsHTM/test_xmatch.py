path='../../data'

import catsHTM

#catsHTM.xmatch_2cats('FIRST','AKARI',catalogs_dir=path)

catsHTM.xmatch_2cats('FIRST','TMASSSxsc',catalogs_dir=path,Search_radius=10, save_results=True)